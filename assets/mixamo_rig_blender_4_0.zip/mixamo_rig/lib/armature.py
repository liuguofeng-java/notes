import bpy


def restore_armature_layers(layers_select):
    armature = bpy.context.active_object.data

    # Check if the active object is an Armature
    if not isinstance(armature, bpy.types.Armature):
        return

    # Iterate over all bones and restore their original hide status
    for bone, hide_status in zip(armature.bones, layers_select):
        bone.hide = hide_status


def enable_all_armature_layers():
    armature = bpy.context.active_object.data

    # Ensure the active object is an Armature
    if not isinstance(armature, bpy.types.Armature):
        return []

    layers_select = []

    # Iterate over all bones
    for bone in armature.bones:
        # Store the current hide status
        layers_select.append(bone.hide)

        # Make the bone visible
        bone.hide = False

    return layers_select
