import bpy

def get_data_bone(name):
    print(f"Getting bone: {name}")
    bone = bpy.context.active_object.data.bones.get(name)
    print(f"Bone found: {bone}")
    return bone

def set_bone_layer(databone, collection_name):
    if databone is None:
        print("No bone provided. Exiting function.")
        return

    # Ensure collection_name is a string
    if not isinstance(collection_name, str):
        print(f"Invalid collection name: {collection_name}. It must be a string.")
        return

    print(f"Setting up collection for bone: {databone.name} in collection: {collection_name}")

    if bpy.context.object.type != 'ARMATURE':
        print("Active object is not an armature. Exiting function.")
        return

    armature = bpy.context.object.data

    print(f"Current Armature: {armature}")
    print("Collection Name:", collection_name)
    bcoll = armature.collections.get(collection_name)
    if bcoll is None:
        print(f"Collection {collection_name} not found. Creating new collection.")
        bcoll = armature.collections.new(collection_name)
    else:
        print(f"Collection {collection_name} found.")

    pose_bone = bpy.context.object.pose.bones.get(databone.name)
    if pose_bone:
        print(f"Assigning {pose_bone.name} to collection {bcoll.name}")
        bcoll.assign(pose_bone)
    else:
        print(f"Pose bone {databone.name} not found.")
